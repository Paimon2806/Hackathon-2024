const API_URL = "https://elastic-newton-sad.lemme.cloud/api/htmhello";

export default API_URL;